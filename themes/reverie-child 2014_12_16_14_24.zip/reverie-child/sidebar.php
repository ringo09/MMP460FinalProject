<aside id="sidebar" class="small-12 large-4 columns">
	<div class="large-12  columns">
		<?php dynamic_sidebar("Sidebar"); ?>
	</div>
</aside><!-- /#sidebar -->