This code uses fancybox: [http://fancyapps.com/fancybox](http://fancyapps.com/fancybox)

and is modified from this Tuts+ tutorial: [http://code.tutsplus.com/tutorials/add-a-responsive-lightbox-to-your-wordpress-theme--wp-28100](http://code.tutsplus.com/tutorials/add-a-responsive-lightbox-to-your-wordpress-theme--wp-28100)

The files mostly from the tutorial are:

* fancybox-wp-init
* and the add fancybox function in functions.php